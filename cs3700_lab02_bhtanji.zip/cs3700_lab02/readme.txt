Look at run 17267 instead of the other one (you can if you like) 

the other one was a test I rand with random numbers limited to 10;
